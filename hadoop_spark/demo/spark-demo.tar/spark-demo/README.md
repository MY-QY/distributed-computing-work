Spark examples
==============

Simple examples of using the [Apache Spark](http://spark.apache.org/).

It's a fork of the [official examples](https://github.com/apache/spark/tree/master/examples/src/main/java/org/apache/spark/examples) rewritten for Java 8.
